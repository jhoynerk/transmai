jQuery( document ).ready(function() {
    jQuery('.carousel').carousel()
});

